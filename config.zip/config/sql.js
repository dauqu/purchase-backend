const config = {
    user: 'rishu',
    password: 'Rishu@123$',
    server: '172.107.166.110',
    database : 'loweena',
    options : {
        trustedConnnection: true,
        enableArithPort : true,
        instancename : 'SQLEXPRESS',   
        trustServerCertificate: true
    },
    port: 1433
}
module.exports = config